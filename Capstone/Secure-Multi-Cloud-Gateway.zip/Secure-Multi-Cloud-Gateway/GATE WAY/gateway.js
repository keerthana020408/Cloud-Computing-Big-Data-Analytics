const express = require("express");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();

const PORT = 3000;
const JWT_SECRET = "secure-multi-cloud-secret";

// Middleware
app.use(cors());
app.use(express.json());


// =====================================================
// GATEWAY HOME
// =====================================================

app.get("/", (req, res) => {

    res.json({

        service: "Secure Multi-Cloud API Gateway",

        status: "ONLINE",

        port: PORT,

        authentication: "JWT ACTIVE",

        services: {

            AWS: "http://localhost:5001",

            Azure: "http://localhost:5002",

            GCP: "http://localhost:5003"

        },

        message: "Gateway is running successfully"

    });

});


// =====================================================
// LOGIN
// =====================================================

app.post("/login", (req, res) => {

    const {
        username,
        password
    } = req.body;

    console.log(
        "Login request received for:",
        username
    );


    // VALID LOGIN

    if (
        username === "student" &&
        password === "user123"
    ) {

        const token = jwt.sign(

            {
                username: username,

                role: "student"

            },

            JWT_SECRET,

            {
                expiresIn: "1h"
            }

        );

        console.log("Login successful");

        console.log("JWT generated successfully");


        return res.json({

            success: true,

            message: "Login successful",

            token: token

        });

    }


    // INVALID LOGIN

    console.log(
        "Invalid username or password"
    );


    return res.status(401).json({

        success: false,

        message: "Invalid username or password"

    });

});


// =====================================================
// JWT VERIFICATION
// =====================================================

function verifyToken(req, res, next) {

    const authHeader =
        req.headers.authorization;


    if (!authHeader) {

        console.log(
            "Access denied - JWT missing"
        );

        return res.status(401).json({

            success: false,

            message:
                "Access denied. JWT token required."

        });

    }


    const parts =
        authHeader.split(" ");


    if (
        parts.length !== 2 ||
        parts[0] !== "Bearer"
    ) {

        return res.status(401).json({

            success: false,

            message:
                "Invalid authorization format."

        });

    }


    const token =
        parts[1];


    try {

        const decoded =
            jwt.verify(
                token,
                JWT_SECRET
            );


        req.user =
            decoded;


        console.log(
            "JWT verified successfully"
        );


        next();

    }

    catch (error) {

        console.log(
            "JWT verification failed"
        );


        return res.status(403).json({

            success: false,

            message:
                "Invalid or expired JWT token."

        });

    }

}


// =====================================================
// AWS ROUTE
// =====================================================

app.get(
    "/api/users",
    verifyToken,
    async (req, res) => {

        console.log(
            "Routing request to AWS User Service"
        );


        try {

            const response =
                await fetch(
                    "http://localhost:5001/users"
                );


            const data =
                await response.json();


            console.log(
                "AWS response received"
            );


            res.json({

                gateway:
                    "Secure Multi-Cloud Gateway",

                authenticatedUser:
                    req.user.username,

                cloud:
                    "AWS",

                data:
                    data

            });

        }

        catch (error) {

            console.log(
                "AWS service unavailable"
            );


            res.status(503).json({

                success: false,

                message:
                    "AWS service is not running.",

                expectedService:
                    "http://localhost:5001"

            });

        }

    }
);


// =====================================================
// AZURE ROUTE
// =====================================================

app.get(
    "/api/courses",
    verifyToken,
    async (req, res) => {

        console.log(
            "Routing request to Azure Course Service"
        );


        try {

            const response =
                await fetch(
                    "http://localhost:5002/courses"
                );


            const data =
                await response.json();


            console.log(
                "Azure response received"
            );


            res.json({

                gateway:
                    "Secure Multi-Cloud Gateway",

                authenticatedUser:
                    req.user.username,

                cloud:
                    "Azure",

                data:
                    data

            });

        }

        catch (error) {

            console.log(
                "Azure service unavailable"
            );


            res.status(503).json({

                success: false,

                message:
                    "Azure service is not running.",

                expectedService:
                    "http://localhost:5002"

            });

        }

    }
);


// =====================================================
// GCP ROUTE
// =====================================================

app.get(
    "/api/notifications",
    verifyToken,
    async (req, res) => {

        console.log(
            "Routing request to GCP Notification Service"
        );


        try {

            const response =
                await fetch(
                    "http://localhost:5003/notifications"
                );


            const data =
                await response.json();


            console.log(
                "GCP response received"
            );


            res.json({

                gateway:
                    "Secure Multi-Cloud Gateway",

                authenticatedUser:
                    req.user.username,

                cloud:
                    "GCP",

                data:
                    data

            });

        }

        catch (error) {

            console.log(
                "GCP service unavailable"
            );


            res.status(503).json({

                success: false,

                message:
                    "GCP service is not running.",

                expectedService:
                    "http://localhost:5003"

            });

        }

    }
);


// =====================================================
// START SERVER
// =====================================================

app.listen(
    PORT,
    () => {

        console.log("");

        console.log(
            "=========================================="
        );

        console.log(
            "     SECURE MULTI-CLOUD API GATEWAY"
        );

        console.log(
            "=========================================="
        );

        console.log(
            "Gateway Status : ONLINE"
        );

        console.log(
            "Gateway URL    : http://localhost:3000"
        );

        console.log(
            "JWT            : ACTIVE"
        );

        console.log(
            "CORS           : ENABLED"
        );

        console.log(
            "------------------------------------------"
        );

        console.log(
            "AWS Service    : http://localhost:5001"
        );

        console.log(
            "Azure Service  : http://localhost:5002"
        );

        console.log(
            "GCP Service    : http://localhost:5003"
        );

        console.log(
            "=========================================="
        );

        console.log("");

    }
);