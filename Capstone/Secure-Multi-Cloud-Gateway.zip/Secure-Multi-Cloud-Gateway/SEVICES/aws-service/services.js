const express = require("express");
const cors = require("cors");

const app = express();

const PORT = 5001;

app.use(cors());
app.use(express.json());


// AWS USER SERVICE
app.get("/users", (req, res) => {

    console.log("AWS User Service request received");

    res.json({
        service: "AWS User Service",
        status: "ONLINE",
        cloud: "AWS",
        users: [
            {
                id: 1,
                name: "Keerthana",
                email: "keerthana@example.com"
            },
            {
                id: 2,
                name: "Student User",
                email: "student@example.com"
            }
        ],
        message: "User data retrieved successfully"
    });

});


// START SERVER
app.listen(PORT, () => {

    console.log("");
    console.log("====================================");
    console.log("       AWS USER SERVICE");
    console.log("====================================");
    console.log("Status : ONLINE");
    console.log("Port   : 5001");
    console.log("URL    : http://localhost:5001");
    console.log("====================================");
    console.log("");

});