const express = require("express");

const app = express();

app.use(express.json());

app.get("/notifications", (req, res) => {
    res.json({
        cloud: "Google Cloud",
        service: "Notification Service",
        status: "success",
        notifications: [
            {
                id: 1,
                message: "Welcome to the multi-cloud platform"
            },
            {
                id: 2,
                message: "Your service request was received"
            }
        ]
    });
});

app.get("/health", (req, res) => {
    res.json({
        cloud: "Google Cloud",
        status: "healthy"
    });
});

app.listen(5003, () => {
    console.log("Google Cloud Notification Service running on port 5003");
});