const express = require("express");

const app = express();

app.use(express.json());

app.get("/courses", (req, res) => {
    res.json({
        cloud: "Microsoft Azure",
        service: "Course Service",
        status: "success",
        courses: [
            {
                id: 101,
                name: "Cloud Computing"
            },
            {
                id: 102,
                name: "Web Technology"
            },
            {
                id: 103,
                name: "Compiler Design"
            }
        ]
    });
});

app.get("/health", (req, res) => {
    res.json({
        cloud: "Microsoft Azure",
        status: "healthy"
    });
});

app.listen(5002, () => {
    console.log("Azure Course Service running on port 5002");
});